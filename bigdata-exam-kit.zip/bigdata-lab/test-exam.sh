#!/usr/bin/env bash
# Runs all exam-practice solutions (MapReduce, Pig, Hive) and checks them against
# tests/expected.  macOS / Linux.   Usage:
#   bash test-exam.sh            all three (about 5-10 minutes)
#   bash test-exam.sh pig        only one tool:  mr | pig | hive
cd "$(dirname "$0")" || exit 1
docker info >/dev/null 2>&1 || { echo "Docker is not running. Start Docker Desktop (or OrbStack) and try again."; exit 1; }
WHAT="${1:-all}"
case "$WHAT" in all|mr|pig|hive) ;; *) echo "Usage: bash test-exam.sh [all|mr|pig|hive]"; exit 2 ;; esac
[ "$WHAT" = all ] && rm -rf output/tests
if [ "$WHAT" = all ] || [ "$WHAT" = mr ]; then
    echo; echo "===== MapReduce ====="; docker compose run --rm hadoop bash /lab/tests/mr_tests.sh
fi
if [ "$WHAT" = all ] || [ "$WHAT" = pig ]; then
    echo; echo "===== Pig ====="; docker compose run --rm pig bash /lab/tests/pig_tests.sh
fi
if [ "$WHAT" = all ] || [ "$WHAT" = hive ]; then
    echo; echo "===== Hive ====="; docker compose run --rm --entrypoint bash hive /lab/tests/hive_tests.sh
fi
echo; echo "===== Checking results ====="
docker compose run --rm hadoop bash /lab/tests/compare.sh
