#!/usr/bin/env bash
# Compares the results in output/tests/{mr,pig,hive} with tests/expected (Hadoop container).
# Numbers are compared after rounding to 2 decimals (difference up to 0.01 allowed);
# the order of lines is ignored.
cd /lab || exit 1
export LC_ALL=C

norm() {   # file(s) -> one normalised line per row, sorted
    cat "$@" 2>/dev/null | tr -d '\r' | awk -F'[,\t]' '
        NF == 0 { next }
        { out = ""
          for (i = 1; i <= NF; i++) {
              v = $i; gsub(/^[ ]+|[ ]+$/, "", v)
              if (v ~ /^-?[0-9]+(\.[0-9]+)?([eE][-+]?[0-9]+)?$/) v = sprintf("%.2f", v + 0)
              out = out (i > 1 ? "," : "") v
          }
          print out }' | sort
}

same() {   # same <expected-normalised> <got-normalised>
    awk -F',' '
        FILENAME == ARGV[1] { e[++ne] = $0; next }
        { g[++ng] = $0 }
        END {
            if (ne != ng) exit 1
            for (i = 1; i <= ne; i++) {
                n = split(e[i], a, ","); m = split(g[i], b, ",")
                if (n != m) exit 1
                for (j = 1; j <= n; j++) {
                    if (a[j] == b[j]) continue
                    if (a[j] ~ /^-?[0-9.]+$/ && b[j] ~ /^-?[0-9.]+$/) {
                        d = a[j] - b[j]; if (d < 0) d = -d
                        if (d <= 0.0101) continue
                    }
                    exit 1
                }
            }
        }' "$1" "$2"
}

OK=0; BAD=0; FAILED=""
TMP=$(mktemp -d)
for TOOL in mr pig hive; do
    [ -d "output/tests/$TOOL" ] || { echo; echo "== $TOOL: not run (no results)"; continue; }
    echo; echo "== $TOOL"
    for EXP in tests/expected/*.txt; do
        NAME=$(basename "$EXP" .txt)
        case "$NAME" in *_m[0-9]*) [ "$TOOL" = mr ] || continue ;; *) [ "$TOOL" = mr ] && continue ;; esac
        DIR="output/tests/$TOOL/$NAME"
        norm "$EXP" > "$TMP/e"
        if [ ! -d "$DIR" ]; then
            echo "  [MISSING] $NAME  (no result folder)"; BAD=$((BAD+1)); FAILED="$FAILED $TOOL:$NAME"; continue
        fi
        norm $(ls "$DIR"/* 2>/dev/null | grep -v '/[._]') > "$TMP/g"
        if same "$TMP/e" "$TMP/g"; then
            echo "  [OK]   $NAME"; OK=$((OK+1))
        else
            echo "  [FAIL] $NAME"; BAD=$((BAD+1)); FAILED="$FAILED $TOOL:$NAME"
            echo "         expected: $(tr '\n' ' ' < "$TMP/e")"
            echo "         got:      $(tr '\n' ' ' < "$TMP/g")"
        fi
    done
done
rm -rf "$TMP"
echo
echo "RESULT: $OK passed, $BAD failed"
[ "$BAD" -eq 0 ] && echo "ALL TESTS PASSED" || echo "Failed:$FAILED"
