#!/usr/bin/env bash
# Runs the MapReduce test questions (Hadoop container). Results: output/tests/mr/<name>
cd /lab || exit 1
R=output/tests/mr
rm -rf "$R"; mkdir -p "$R"
export HADOOP_ROOT_LOGGER=WARN,console

echo ">> compiling CsvQuery and Template"
for C in CsvQuery Template; do
    rm -rf "build/$C"; mkdir -p "build/$C"
    javac -cp "$(hadoop classpath)" -d "build/$C" "scripts/hadoop/$C.java" || { echo "[FAIL] $C.java does not compile"; exit 1; }
    jar cf "build/$C.jar" -C "build/$C" .
done

t() {   # t <name> <input> <arguments for CsvQuery ...>
    local name="$1" in="$2"; shift 2
    echo ">> $name: CsvQuery $in $*"
    hadoop jar build/CsvQuery.jar CsvQuery "$in" "$R/$name" "$@" >"$R/$name.log" 2>&1 \
        || { echo "   job failed:"; tail -n 15 "$R/$name.log"; }
}

t bank_m1       data/bank_transactions.csv    Branch sum Amount
t bank_m2       data/bank_transactions.csv    Customer_ID sum Amount Transaction_Type=Deposit
t bank_m3       data/bank_transactions.csv    Account_Type avg Amount
t learning_m1   data/learning_activity.csv    Course_ID avg Quiz_Score
t learning_m2   data/learning_activity.csv    Activity_Type count
t library_m1    data/library_transactions.csv Category sum Fine_Amount
t library_m2    data/library_transactions.csv Member_ID count Fine_Amount\>0
t medical_m1    data/medical_records.csv      Diagnosis count
t medical_m2    data/medical_records.csv      Diagnosis max Blood_Sugar
t pharmacy_m1   data/pharmacy_inventory.csv   Category sum Unit_Price*Stock_Quantity
t pharmacy_m2   data/pharmacy_inventory.csv   ALL count Stock_Quantity\<Reorder_Level
t pharmacy_m3   data/pharmacy_inventory.csv   Supplier_ID list Medicine_Name Stock_Quantity\<Reorder_Level
t retail_m1     data/retail_sales.csv         Category sum Quantity*Unit_Price
t retail_m2     data/retail_sales.csv         Region count
t shipment_m1   data/shipment_records.csv     Delivery_Status count
t shipment_m2   data/shipment_records.csv     Transport_Mode avg Shipping_Cost
t attendance_m1 data/student_attendance.csv   Student_ID sum Attended_Classes
t attendance_m2 data/student_attendance.csv   Department avg Attended_Classes*100/Total_Classes
t web_m1        data/web_clicks.csv           Country count
t web_m2        data/web_clicks.csv           Device_Type avg Duration_Seconds
t web_m3        data/web_clicks.csv           Country countdistinct User_ID

echo ">> template_m1: Template (as delivered)"
hadoop jar build/Template.jar Template data/bank_transactions.csv "$R/template_m1" >"$R/template_m1.log" 2>&1 \
    || { echo "   job failed:"; tail -n 15 "$R/template_m1.log"; }
echo ">> MapReduce tests finished"
