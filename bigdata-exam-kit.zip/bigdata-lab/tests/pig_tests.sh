#!/usr/bin/env bash
# Runs every scripts/pig/<dataset>.pig (Pig container). Each "DUMP qN;" is turned into
#   STORE qN INTO '/lab/output/tests/pig/<dataset>_qN' USING PigStorage(',');
# so that compare.sh can check the results. The scripts themselves are not changed.
cd /lab || exit 1
R=/lab/output/tests/pig
rm -rf "$R"; mkdir -p "$R"
for F in scripts/pig/*.pig; do
    DS=$(basename "$F" .pig)
    [ "$DS" = template ] && continue
    T="/tmp/test_$DS.pig"
    tr -d '\r' < "$F" | sed -E "s#^[[:space:]]*DUMP[[:space:]]+([A-Za-z0-9_]+)[[:space:]]*;#STORE \1 INTO '$R/${DS}_\1' USING PigStorage(',');#I" > "$T"
    echo ">> $DS ($(grep -c '^STORE' "$T") questions)"
    if pig -x local -l /tmp "$T" > "/tmp/pig_$DS.out" 2>&1; then
        echo "   finished"
    else
        echo "   FAILED. Last messages:"
        grep -E 'ERROR|Exception|error' "/tmp/pig_$DS.out" | head -n 8
    fi
done
echo ">> Pig tests finished"
