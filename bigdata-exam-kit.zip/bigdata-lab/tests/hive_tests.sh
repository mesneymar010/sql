#!/usr/bin/env bash
# Runs every scripts/hive/<dataset>.hql in ONE Hive session (Hive container, started with
# --entrypoint bash). Each question's SELECT is turned into
#   INSERT OVERWRITE LOCAL DIRECTORY '/tmp/hivetest/<dataset>_qN' ... SELECT ...
# (label statements like  SELECT 'Q1 ...';  are skipped), then the result folders are
# copied to /lab/output/tests/hive for compare.sh.
cd /lab || exit 1
W=/tmp/hivetest
COMBINED=/tmp/hive_all_tests.hql
rm -rf "$W" "$COMBINED"
: > "$COMBINED"

for F in scripts/hive/*.hql; do
    DS=$(basename "$F" .hql)
    [ "$DS" = template ] && continue
    N=0
    CONTENT=$(tr -d '\r' < "$F")
    IFS=';' read -r -d '' -a STMTS <<< "$CONTENT"
    for S in "${STMTS[@]}"; do
        S="${S#"${S%%[![:space:]]*}"}"          # trim leading space/newlines
        S="${S%"${S##*[![:space:]]}"}"          # trim trailing space/newlines
        [ -z "$S" ] && continue
        UP=$(printf '%s' "$S" | tr '[:lower:]' '[:upper:]')
        if [[ "$UP" == "SELECT '"* ]]; then
            continue                                                  # label only
        elif [[ "$UP" == SELECT* ]]; then
            N=$((N+1))
            printf "INSERT OVERWRITE LOCAL DIRECTORY '%s/%s_q%d' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' %s;\n" \
                "$W" "$DS" "$N" "$S" >> "$COMBINED"
        else
            printf '%s;\n' "$S" >> "$COMBINED"
        fi
    done
    echo ">> $DS: $N questions"
done

bash /opt/hive/start-hive.sh -f "$COMBINED" --force=true
RC=$?
echo
echo ">> Hive finished (exit code $RC). Copying results to output/tests/hive"
rm -rf /lab/output/tests/hive && mkdir -p /lab/output/tests/hive \
  && { [ -d "$W" ] && cp -r "$W"/. /lab/output/tests/hive/ ; true; } \
  || echo "ERROR: could not write to /lab/output/tests/hive"
