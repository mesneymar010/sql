@echo off
rem Runs all exam-practice solutions (MapReduce, Pig, Hive) and checks them.  Windows.
rem   test-exam.bat          all three (about 5-10 minutes)
rem   test-exam.bat pig      only one tool:  mr ^| pig ^| hive
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Docker is not running. Start Docker Desktop and try again.
  pause
  exit /b 1
)
set WHAT=%1
if "%WHAT%"=="" set WHAT=all
if "%WHAT%"=="all" if exist output\tests rmdir /s /q output\tests
if "%WHAT%"=="all" goto mr
if "%WHAT%"=="mr" goto mr
if "%WHAT%"=="pig" goto pig
if "%WHAT%"=="hive" goto hive
echo Usage: test-exam.bat [all^|mr^|pig^|hive]
pause
exit /b 2
:mr
echo.
echo ===== MapReduce =====
docker compose run --rm hadoop bash /lab/tests/mr_tests.sh
if not "%WHAT%"=="all" goto check
:pig
echo.
echo ===== Pig =====
docker compose run --rm pig bash /lab/tests/pig_tests.sh
if not "%WHAT%"=="all" goto check
:hive
echo.
echo ===== Hive =====
docker compose run --rm --entrypoint bash hive /lab/tests/hive_tests.sh
:check
echo.
echo ===== Checking results =====
docker compose run --rm hadoop bash /lab/tests/compare.sh
pause
