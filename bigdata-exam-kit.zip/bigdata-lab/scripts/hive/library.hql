CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS library;
CREATE TABLE library (
  Transaction_ID STRING, Member_ID STRING, Book_ID STRING, Category STRING,
  Issue_Date STRING, Return_Date STRING, Fine_Amount INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/library_transactions.csv' OVERWRITE INTO TABLE library;

SELECT 'Q1 Total fine per category';
SELECT Category, SUM(Fine_Amount) AS total_fine FROM library GROUP BY Category;

SELECT 'Q2 Number of books issued per member';
SELECT Member_ID, COUNT(*) AS books FROM library GROUP BY Member_ID;

SELECT 'Q3 Transactions with a fine';
SELECT Transaction_ID, Member_ID, Fine_Amount FROM library WHERE Fine_Amount > 0;

SELECT 'Q4 Books kept more than 14 days';
SELECT Transaction_ID, Book_ID, DATEDIFF(Return_Date, Issue_Date) AS days_kept FROM library
WHERE DATEDIFF(Return_Date, Issue_Date) > 14;

SELECT 'Q5 Books issued more than once';
SELECT Book_ID, COUNT(*) AS times_issued FROM library GROUP BY Book_ID HAVING COUNT(*) > 1;

SELECT 'Q6 Number of different members per category';
SELECT Category, COUNT(DISTINCT Member_ID) AS members FROM library GROUP BY Category;
