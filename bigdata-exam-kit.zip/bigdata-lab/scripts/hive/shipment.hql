CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS shipment;
CREATE TABLE shipment (
  Shipment_ID STRING, Customer_ID STRING, Source_City STRING, Destination_City STRING,
  Transport_Mode STRING, Weight_KG INT, Shipping_Cost INT, Delivery_Status STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/shipment_records.csv' OVERWRITE INTO TABLE shipment;

SELECT 'Q1 Number of shipments per delivery status';
SELECT Delivery_Status, COUNT(*) AS shipments FROM shipment GROUP BY Delivery_Status;

SELECT 'Q2 Average shipping cost per transport mode';
SELECT Transport_Mode, ROUND(AVG(Shipping_Cost), 2) AS avg_cost FROM shipment GROUP BY Transport_Mode;

SELECT 'Q3 Delayed shipments';
SELECT Shipment_ID, Source_City, Destination_City, Transport_Mode FROM shipment
WHERE Delivery_Status = 'Delayed';

SELECT 'Q4 Top 3 shipments by cost per kg';
SELECT Shipment_ID, ROUND(Shipping_Cost / Weight_KG, 2) AS cost_per_kg FROM shipment
ORDER BY cost_per_kg DESC LIMIT 3;

SELECT 'Q5 Total weight per source city';
SELECT Source_City, SUM(Weight_KG) AS total_weight FROM shipment GROUP BY Source_City;

SELECT 'Q6 Shipments and total cost per destination city';
SELECT Destination_City, COUNT(*) AS shipments, SUM(Shipping_Cost) AS total_cost
FROM shipment GROUP BY Destination_City;
