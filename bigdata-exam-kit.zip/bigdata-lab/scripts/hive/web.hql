CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS web;
CREATE TABLE web (
  Click_ID STRING, User_ID STRING, Country STRING, Device_Type STRING,
  Page_Category STRING, Click_Time STRING, Session_ID STRING, Duration_Seconds INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/web_clicks.csv' OVERWRITE INTO TABLE web;

SELECT 'Q1 Number of clicks per country';
SELECT Country, COUNT(*) AS num_clicks FROM web GROUP BY Country;

SELECT 'Q2 Average duration (seconds) per device type';
SELECT Device_Type, ROUND(AVG(Duration_Seconds), 2) AS avg_duration FROM web GROUP BY Device_Type;

SELECT 'Q3 Total duration per page category (highest first)';
SELECT Page_Category, SUM(Duration_Seconds) AS total_duration FROM web
GROUP BY Page_Category ORDER BY total_duration DESC;

SELECT 'Q4 Clicks on the Checkout page';
SELECT Click_ID, User_ID, Country FROM web WHERE Page_Category = 'Checkout';

SELECT 'Q5 Number of clicks per day';
SELECT SUBSTR(Click_Time, 1, 10) AS click_day, COUNT(*) AS num_clicks FROM web
GROUP BY SUBSTR(Click_Time, 1, 10);

SELECT 'Q6 Number of different users per country';
SELECT Country, COUNT(DISTINCT User_ID) AS users FROM web GROUP BY Country;
