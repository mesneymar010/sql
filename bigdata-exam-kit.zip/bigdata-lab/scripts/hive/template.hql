CREATE DATABASE IF NOT EXISTS exam;
USE exam;

SELECT '1. Create a table for a CSV file with a header line, then load the file';
DROP TABLE IF EXISTS bank;
CREATE TABLE bank (
  Transaction_ID STRING, Customer_ID STRING, Account_Type STRING, Transaction_Type STRING,
  Amount INT, Branch STRING, Transaction_Date STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/bank_transactions.csv' OVERWRITE INTO TABLE bank;
SHOW TABLES;
DESCRIBE bank;
SELECT * FROM bank LIMIT 5;

SELECT '2. Filter rows (WHERE)';
SELECT Transaction_ID, Customer_ID, Amount FROM bank
WHERE Transaction_Type = 'Deposit' AND Amount >= 5000;

SELECT '3. Group and aggregate (COUNT, SUM, AVG, MAX, MIN)';
SELECT Branch, COUNT(*) AS cnt, SUM(Amount) AS total, ROUND(AVG(Amount), 2) AS average,
       MAX(Amount) AS highest, MIN(Amount) AS lowest
FROM bank GROUP BY Branch;

SELECT '4. Condition on a group (HAVING)';
SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch HAVING SUM(Amount) > 10000;

SELECT '5. Top N (ORDER BY ... DESC LIMIT N)';
SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch ORDER BY total DESC LIMIT 3;

SELECT '6. Calculated column with CASE, and count of different values';
SELECT Customer_ID,
       SUM(CASE WHEN Transaction_Type = 'Deposit' THEN Amount ELSE -Amount END) AS net,
       COUNT(DISTINCT Branch) AS branches
FROM bank GROUP BY Customer_ID;

SELECT '7. Dates and text: month from a date, days between two dates';
SELECT SUBSTR(Transaction_Date, 1, 7) AS txn_month, COUNT(*) AS cnt FROM bank
GROUP BY SUBSTR(Transaction_Date, 1, 7);
SELECT Transaction_ID, DATEDIFF('2026-10-31', Transaction_Date) AS days_ago FROM bank LIMIT 3;

SELECT '8. JOIN: each transaction with the total of its branch';
SELECT b.Transaction_ID, b.Branch, b.Amount, t.total
FROM bank b
JOIN (SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch) t
  ON b.Branch = t.Branch;

SELECT '9. Partitioned table (one folder per Branch)';
SET hive.exec.dynamic.partition.mode=nonstrict;
DROP TABLE IF EXISTS bank_by_branch;
CREATE TABLE bank_by_branch (Transaction_ID STRING, Customer_ID STRING, Amount INT)
PARTITIONED BY (Branch STRING);
INSERT OVERWRITE TABLE bank_by_branch PARTITION (Branch)
SELECT Transaction_ID, Customer_ID, Amount, Branch FROM bank;
SHOW PARTITIONS bank_by_branch;
SELECT * FROM bank_by_branch WHERE Branch = 'Chennai';

SELECT '10. View, and saving a result as a CSV folder in output/';
DROP VIEW IF EXISTS branch_totals;
CREATE VIEW branch_totals AS SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch;
SELECT * FROM branch_totals;
INSERT OVERWRITE LOCAL DIRECTORY '/lab/output/hive_branch_totals'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT * FROM branch_totals;
