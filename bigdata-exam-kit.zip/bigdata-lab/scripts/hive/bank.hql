CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS bank;
CREATE TABLE bank (
  Transaction_ID STRING, Customer_ID STRING, Account_Type STRING, Transaction_Type STRING,
  Amount INT, Branch STRING, Transaction_Date STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/bank_transactions.csv' OVERWRITE INTO TABLE bank;

SELECT 'Q1 Total amount per branch';
SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch;

SELECT 'Q2 Count and total amount per transaction type';
SELECT Transaction_Type, COUNT(*) AS cnt, SUM(Amount) AS total FROM bank GROUP BY Transaction_Type;

SELECT 'Q3 Deposits greater than 5000';
SELECT Transaction_ID, Customer_ID, Amount, Branch FROM bank
WHERE Transaction_Type = 'Deposit' AND Amount > 5000;

SELECT 'Q4 Net balance per customer (deposits minus withdrawals)';
SELECT Customer_ID, SUM(CASE WHEN Transaction_Type = 'Deposit' THEN Amount ELSE -Amount END) AS net
FROM bank GROUP BY Customer_ID;

SELECT 'Q5 Top 3 branches by total amount';
SELECT Branch, SUM(Amount) AS total FROM bank GROUP BY Branch ORDER BY total DESC LIMIT 3;

SELECT 'Q6 Average amount per account type';
SELECT Account_Type, ROUND(AVG(Amount), 2) AS avg_amount FROM bank GROUP BY Account_Type;
