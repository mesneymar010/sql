CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS medical;
CREATE TABLE medical (
  Patient_ID STRING, Age INT, Gender STRING, Diagnosis STRING,
  Blood_Sugar INT, Blood_Pressure STRING, Doctor_Specialization STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/medical_records.csv' OVERWRITE INTO TABLE medical;

SELECT 'Q1 Number of patients per diagnosis';
SELECT Diagnosis, COUNT(*) AS patients FROM medical GROUP BY Diagnosis;

SELECT 'Q2 Average blood sugar per diagnosis';
SELECT Diagnosis, ROUND(AVG(Blood_Sugar), 2) AS avg_sugar FROM medical GROUP BY Diagnosis;

SELECT 'Q3 Patients with blood sugar above 140';
SELECT Patient_ID, Age, Blood_Sugar FROM medical WHERE Blood_Sugar > 140;

SELECT 'Q4 Average age per gender';
SELECT Gender, ROUND(AVG(Age), 2) AS avg_age FROM medical GROUP BY Gender;

SELECT 'Q5 Patients with systolic blood pressure 140 or more';
SELECT Patient_ID,
       CAST(SPLIT(Blood_Pressure, '/')[0] AS INT) AS systolic,
       CAST(SPLIT(Blood_Pressure, '/')[1] AS INT) AS diastolic
FROM medical WHERE CAST(SPLIT(Blood_Pressure, '/')[0] AS INT) >= 140;

SELECT 'Q6 Number of patients per age group';
SELECT age_group, COUNT(*) AS patients FROM (
  SELECT CASE WHEN Age < 40 THEN 'Below 40'
              WHEN Age < 60 THEN '40-59'
              ELSE '60 and above' END AS age_group
  FROM medical) t
GROUP BY age_group;
