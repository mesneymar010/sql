CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS retail;
CREATE TABLE retail (
  Order_ID STRING, Customer_ID STRING, Product_ID STRING, Category STRING,
  Quantity INT, Unit_Price INT, Region STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/retail_sales.csv' OVERWRITE INTO TABLE retail;

SELECT 'Q1 Revenue (quantity x unit price) per category';
SELECT Category, SUM(Quantity * Unit_Price) AS revenue FROM retail GROUP BY Category;

SELECT 'Q2 Revenue per region';
SELECT Region, SUM(Quantity * Unit_Price) AS revenue FROM retail GROUP BY Region;

SELECT 'Q3 Orders with order value above 20000';
SELECT Order_ID, Customer_ID, Quantity * Unit_Price AS order_value FROM retail
WHERE Quantity * Unit_Price > 20000;

SELECT 'Q4 Top 3 customers by total spend';
SELECT Customer_ID, SUM(Quantity * Unit_Price) AS total_spend FROM retail
GROUP BY Customer_ID ORDER BY total_spend DESC LIMIT 3;

SELECT 'Q5 Number of orders and total quantity per category';
SELECT Category, COUNT(*) AS orders, SUM(Quantity) AS total_qty FROM retail GROUP BY Category;

SELECT 'Q6 Average order value per region';
SELECT Region, ROUND(AVG(Quantity * Unit_Price), 2) AS avg_order_value FROM retail GROUP BY Region;
