CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS learning;
CREATE TABLE learning (
  Activity_ID STRING, Student_ID STRING, Course_ID STRING, Activity_Type STRING,
  Time_Spent_Minutes INT, Completion_Percentage INT, Quiz_Score INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/learning_activity.csv' OVERWRITE INTO TABLE learning;

SELECT 'Q1 Average quiz score per course';
SELECT Course_ID, ROUND(AVG(Quiz_Score), 2) AS avg_score FROM learning GROUP BY Course_ID;

SELECT 'Q2 Total time spent (minutes) per student';
SELECT Student_ID, SUM(Time_Spent_Minutes) AS total_minutes FROM learning GROUP BY Student_ID;

SELECT 'Q3 Activities completed 100%';
SELECT Activity_ID, Student_ID, Course_ID FROM learning WHERE Completion_Percentage = 100;

SELECT 'Q4 Number of activities per activity type';
SELECT Activity_Type, COUNT(*) AS cnt FROM learning GROUP BY Activity_Type;

SELECT 'Q5 Top 3 students by average quiz score';
SELECT Student_ID, AVG(Quiz_Score) AS avg_score FROM learning
GROUP BY Student_ID ORDER BY avg_score DESC LIMIT 3;

SELECT 'Q6 Highest, lowest quiz score and number of activities per course';
SELECT Course_ID, MAX(Quiz_Score) AS max_score, MIN(Quiz_Score) AS min_score, COUNT(*) AS cnt
FROM learning GROUP BY Course_ID;
