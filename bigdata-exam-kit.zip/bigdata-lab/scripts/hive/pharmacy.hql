CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS pharmacy;
CREATE TABLE pharmacy (
  Medicine_ID STRING, Medicine_Name STRING, Category STRING, Supplier_ID STRING,
  Unit_Price DOUBLE, Stock_Quantity INT, Reorder_Level INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/pharmacy_inventory.csv' OVERWRITE INTO TABLE pharmacy;

SELECT 'Q1 Medicines below reorder level';
SELECT Medicine_ID, Medicine_Name, Stock_Quantity, Reorder_Level FROM pharmacy
WHERE Stock_Quantity < Reorder_Level;

SELECT 'Q2 Stock value (price x quantity) per category';
SELECT Category, SUM(Unit_Price * Stock_Quantity) AS stock_value FROM pharmacy GROUP BY Category;

SELECT 'Q3 Number of medicines per supplier';
SELECT Supplier_ID, COUNT(*) AS medicines FROM pharmacy GROUP BY Supplier_ID;

SELECT 'Q4 Average unit price per category';
SELECT Category, ROUND(AVG(Unit_Price), 2) AS avg_price FROM pharmacy GROUP BY Category;

SELECT 'Q5 Top 3 medicines by stock value';
SELECT Medicine_Name, Unit_Price * Stock_Quantity AS stock_value FROM pharmacy
ORDER BY stock_value DESC LIMIT 3;

SELECT 'Q6 Total stock quantity and stock value per supplier';
SELECT Supplier_ID, SUM(Stock_Quantity) AS total_qty, SUM(Unit_Price * Stock_Quantity) AS stock_value
FROM pharmacy GROUP BY Supplier_ID;
