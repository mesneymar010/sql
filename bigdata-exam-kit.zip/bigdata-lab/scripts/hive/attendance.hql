CREATE DATABASE IF NOT EXISTS exam;
USE exam;
DROP TABLE IF EXISTS attendance;
CREATE TABLE attendance (
  Student_ID STRING, Student_Name STRING, Department STRING, Course_ID STRING,
  Total_Classes INT, Attended_Classes INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
LOAD DATA LOCAL INPATH '/lab/data/student_attendance.csv' OVERWRITE INTO TABLE attendance;

SELECT 'Q1 Course attendance below 75%';
SELECT Student_ID, Course_ID, ROUND(Attended_Classes * 100.0 / Total_Classes, 2) AS att_pct
FROM attendance WHERE Attended_Classes * 100.0 / Total_Classes < 75;

SELECT 'Q2 Overall attendance % per student';
SELECT Student_ID, Student_Name, ROUND(SUM(Attended_Classes) * 100.0 / SUM(Total_Classes), 2) AS att_pct
FROM attendance GROUP BY Student_ID, Student_Name;

SELECT 'Q3 Overall attendance % per department';
SELECT Department, ROUND(SUM(Attended_Classes) * 100.0 / SUM(Total_Classes), 2) AS att_pct
FROM attendance GROUP BY Department;

SELECT 'Q4 Number of students per department';
SELECT Department, COUNT(DISTINCT Student_ID) AS students FROM attendance GROUP BY Department;

SELECT 'Q5 Top 3 students by overall attendance %';
SELECT Student_ID, Student_Name, ROUND(SUM(Attended_Classes) * 100.0 / SUM(Total_Classes), 2) AS att_pct
FROM attendance GROUP BY Student_ID, Student_Name ORDER BY att_pct DESC LIMIT 3;

SELECT 'Q6 Students and total attended classes per course';
SELECT Course_ID, COUNT(*) AS students, SUM(Attended_Classes) AS total_attended
FROM attendance GROUP BY Course_ID;
