-- learning_activity.csv   Run:  pig -x local scripts/pig/learning.pig
raw = LOAD '/lab/data/learning_activity.csv' USING PigStorage(',')
      AS (Activity_ID:chararray, Student_ID:chararray, Course_ID:chararray, Activity_Type:chararray,
          Time_Spent_Minutes:int, Completion_Percentage:int, Quiz_Score:int);
act = FILTER raw BY Activity_ID != 'Activity_ID';            -- remove the header line

-- Q1 Average quiz score per course
g1 = GROUP act BY Course_ID;
q1 = FOREACH g1 GENERATE group AS Course_ID, ROUND_TO(AVG(act.Quiz_Score), 2) AS avg_score;
DUMP q1;

-- Q2 Total time spent (minutes) per student
g2 = GROUP act BY Student_ID;
q2 = FOREACH g2 GENERATE group AS Student_ID, SUM(act.Time_Spent_Minutes) AS total_minutes;
DUMP q2;

-- Q3 Activities completed 100%
f3 = FILTER act BY Completion_Percentage == 100;
q3 = FOREACH f3 GENERATE Activity_ID, Student_ID, Course_ID;
DUMP q3;

-- Q4 Number of activities per activity type
g4 = GROUP act BY Activity_Type;
q4 = FOREACH g4 GENERATE group AS Activity_Type, COUNT(act) AS cnt;
DUMP q4;

-- Q5 Top 3 students by average quiz score
a5 = FOREACH g2 GENERATE group AS Student_ID, AVG(act.Quiz_Score) AS avg_score;
o5 = ORDER a5 BY avg_score DESC;
q5 = LIMIT o5 3;
DUMP q5;

-- Q6 Highest, lowest quiz score and number of activities per course
q6 = FOREACH g1 GENERATE group AS Course_ID, MAX(act.Quiz_Score) AS max_score,
       MIN(act.Quiz_Score) AS min_score, COUNT(act) AS cnt;
DUMP q6;
