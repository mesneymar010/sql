-- student_attendance.csv   Run:  pig -x local scripts/pig/attendance.pig
raw = LOAD '/lab/data/student_attendance.csv' USING PigStorage(',')
      AS (Student_ID:chararray, Student_Name:chararray, Department:chararray, Course_ID:chararray,
          Total_Classes:int, Attended_Classes:int);
att = FILTER raw BY Student_ID != 'Student_ID';              -- remove the header line

-- Q1 Course attendance below 75%  ((double) avoids whole-number division)
p1 = FOREACH att GENERATE Student_ID, Course_ID,
       (double) Attended_Classes * 100 / Total_Classes AS att_pct;
f1 = FILTER p1 BY att_pct < 75;
q1 = FOREACH f1 GENERATE Student_ID, Course_ID, ROUND_TO(att_pct, 2) AS att_pct;
DUMP q1;

-- Q2 Overall attendance % per student
g2 = GROUP att BY (Student_ID, Student_Name);
s2 = FOREACH g2 GENERATE FLATTEN(group) AS (Student_ID, Student_Name),
       (double) SUM(att.Attended_Classes) * 100 / SUM(att.Total_Classes) AS att_pct;
q2 = FOREACH s2 GENERATE Student_ID, Student_Name, ROUND_TO(att_pct, 2) AS att_pct;
DUMP q2;

-- Q3 Overall attendance % per department
g3 = GROUP att BY Department;
q3 = FOREACH g3 GENERATE group AS Department,
       ROUND_TO((double) SUM(att.Attended_Classes) * 100 / SUM(att.Total_Classes), 2) AS att_pct;
DUMP q3;

-- Q4 Number of students per department (each student counted once)
q4 = FOREACH g3 {
       s = DISTINCT att.Student_ID;
       GENERATE group AS Department, COUNT(s) AS students;
     };
DUMP q4;

-- Q5 Top 3 students by overall attendance %
o5 = ORDER s2 BY att_pct DESC;
l5 = LIMIT o5 3;
q5 = FOREACH l5 GENERATE Student_ID, Student_Name, ROUND_TO(att_pct, 2) AS att_pct;
DUMP q5;

-- Q6 Students and total attended classes per course
g6 = GROUP att BY Course_ID;
q6 = FOREACH g6 GENERATE group AS Course_ID, COUNT(att) AS students,
       SUM(att.Attended_Classes) AS total_attended;
DUMP q6;
