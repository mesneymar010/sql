-- retail_sales.csv   Run:  pig -x local scripts/pig/retail.pig
raw = LOAD '/lab/data/retail_sales.csv' USING PigStorage(',')
      AS (Order_ID:chararray, Customer_ID:chararray, Product_ID:chararray, Category:chararray,
          Quantity:int, Unit_Price:int, Region:chararray);
sales = FILTER raw BY Order_ID != 'Order_ID';                -- remove the header line
v = FOREACH sales GENERATE Order_ID, Customer_ID, Category, Region, Quantity,
      Quantity * Unit_Price AS order_value;

-- Q1 Revenue (quantity x unit price) per category
g1 = GROUP v BY Category;
q1 = FOREACH g1 GENERATE group AS Category, SUM(v.order_value) AS revenue;
DUMP q1;

-- Q2 Revenue per region
g2 = GROUP v BY Region;
q2 = FOREACH g2 GENERATE group AS Region, SUM(v.order_value) AS revenue;
DUMP q2;

-- Q3 Orders with order value above 20000
f3 = FILTER v BY order_value > 20000;
q3 = FOREACH f3 GENERATE Order_ID, Customer_ID, order_value;
DUMP q3;

-- Q4 Top 3 customers by total spend
g4 = GROUP v BY Customer_ID;
s4 = FOREACH g4 GENERATE group AS Customer_ID, SUM(v.order_value) AS total_spend;
o4 = ORDER s4 BY total_spend DESC;
q4 = LIMIT o4 3;
DUMP q4;

-- Q5 Number of orders and total quantity per category
q5 = FOREACH g1 GENERATE group AS Category, COUNT(v) AS orders, SUM(v.Quantity) AS total_qty;
DUMP q5;

-- Q6 Average order value per region
q6 = FOREACH g2 GENERATE group AS Region, ROUND_TO(AVG(v.order_value), 2) AS avg_order_value;
DUMP q6;
