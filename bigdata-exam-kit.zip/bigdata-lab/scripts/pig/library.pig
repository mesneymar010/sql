-- library_transactions.csv   Run:  pig -x local scripts/pig/library.pig
raw = LOAD '/lab/data/library_transactions.csv' USING PigStorage(',')
      AS (Transaction_ID:chararray, Member_ID:chararray, Book_ID:chararray, Category:chararray,
          Issue_Date:chararray, Return_Date:chararray, Fine_Amount:int);
lib = FILTER raw BY Transaction_ID != 'Transaction_ID';      -- remove the header line

-- Q1 Total fine per category
g1 = GROUP lib BY Category;
q1 = FOREACH g1 GENERATE group AS Category, SUM(lib.Fine_Amount) AS total_fine;
DUMP q1;

-- Q2 Number of books issued per member
g2 = GROUP lib BY Member_ID;
q2 = FOREACH g2 GENERATE group AS Member_ID, COUNT(lib) AS books;
DUMP q2;

-- Q3 Transactions with a fine
f3 = FILTER lib BY Fine_Amount > 0;
q3 = FOREACH f3 GENERATE Transaction_ID, Member_ID, Fine_Amount;
DUMP q3;

-- Q4 Books kept more than 14 days (date difference)
d4 = FOREACH lib GENERATE Transaction_ID, Book_ID,
       DaysBetween(ToDate(Return_Date, 'yyyy-MM-dd'), ToDate(Issue_Date, 'yyyy-MM-dd')) AS days_kept;
q4 = FILTER d4 BY days_kept > 14;
DUMP q4;

-- Q5 Books issued more than once
g5 = GROUP lib BY Book_ID;
c5 = FOREACH g5 GENERATE group AS Book_ID, COUNT(lib) AS times_issued;
q5 = FILTER c5 BY times_issued > 1;
DUMP q5;

-- Q6 Number of different members per category
q6 = FOREACH g1 {
       m = DISTINCT lib.Member_ID;
       GENERATE group AS Category, COUNT(m) AS members;
     };
DUMP q6;
