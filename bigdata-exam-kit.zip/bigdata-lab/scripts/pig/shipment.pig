-- shipment_records.csv   Run:  pig -x local scripts/pig/shipment.pig
raw = LOAD '/lab/data/shipment_records.csv' USING PigStorage(',')
      AS (Shipment_ID:chararray, Customer_ID:chararray, Source_City:chararray,
          Destination_City:chararray, Transport_Mode:chararray, Weight_KG:int,
          Shipping_Cost:int, Delivery_Status:chararray);
ship = FILTER raw BY Shipment_ID != 'Shipment_ID';           -- remove the header line

-- Q1 Number of shipments per delivery status
g1 = GROUP ship BY Delivery_Status;
q1 = FOREACH g1 GENERATE group AS Delivery_Status, COUNT(ship) AS shipments;
DUMP q1;

-- Q2 Average shipping cost per transport mode
g2 = GROUP ship BY Transport_Mode;
q2 = FOREACH g2 GENERATE group AS Transport_Mode, ROUND_TO(AVG(ship.Shipping_Cost), 2) AS avg_cost;
DUMP q2;

-- Q3 Delayed shipments
f3 = FILTER ship BY Delivery_Status == 'Delayed';
q3 = FOREACH f3 GENERATE Shipment_ID, Source_City, Destination_City, Transport_Mode;
DUMP q3;

-- Q4 Top 3 shipments by cost per kg  ((double) avoids whole-number division)
c4 = FOREACH ship GENERATE Shipment_ID, (double) Shipping_Cost / Weight_KG AS cost_per_kg;
o4 = ORDER c4 BY cost_per_kg DESC;
l4 = LIMIT o4 3;
q4 = FOREACH l4 GENERATE Shipment_ID, ROUND_TO(cost_per_kg, 2) AS cost_per_kg;
DUMP q4;

-- Q5 Total weight per source city
g5 = GROUP ship BY Source_City;
q5 = FOREACH g5 GENERATE group AS Source_City, SUM(ship.Weight_KG) AS total_weight;
DUMP q5;

-- Q6 Shipments and total cost per destination city
g6 = GROUP ship BY Destination_City;
q6 = FOREACH g6 GENERATE group AS Destination_City, COUNT(ship) AS shipments,
       SUM(ship.Shipping_Cost) AS total_cost;
DUMP q6;
