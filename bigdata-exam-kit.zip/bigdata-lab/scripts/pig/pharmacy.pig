-- pharmacy_inventory.csv   Run:  pig -x local scripts/pig/pharmacy.pig
raw = LOAD '/lab/data/pharmacy_inventory.csv' USING PigStorage(',')
      AS (Medicine_ID:chararray, Medicine_Name:chararray, Category:chararray, Supplier_ID:chararray,
          Unit_Price:double, Stock_Quantity:int, Reorder_Level:int);
med = FILTER raw BY Medicine_ID != 'Medicine_ID';            -- remove the header line

-- Q1 Medicines below reorder level (compare two columns)
f1 = FILTER med BY Stock_Quantity < Reorder_Level;
q1 = FOREACH f1 GENERATE Medicine_ID, Medicine_Name, Stock_Quantity, Reorder_Level;
DUMP q1;

-- Q2 Stock value (price x quantity) per category
v  = FOREACH med GENERATE Medicine_Name, Category, Supplier_ID, Stock_Quantity,
       Unit_Price * Stock_Quantity AS stock_value;
g2 = GROUP v BY Category;
q2 = FOREACH g2 GENERATE group AS Category, SUM(v.stock_value) AS stock_value;
DUMP q2;

-- Q3 Number of medicines per supplier
g3 = GROUP med BY Supplier_ID;
q3 = FOREACH g3 GENERATE group AS Supplier_ID, COUNT(med) AS medicines;
DUMP q3;

-- Q4 Average unit price per category
g4 = GROUP med BY Category;
q4 = FOREACH g4 GENERATE group AS Category, ROUND_TO(AVG(med.Unit_Price), 2) AS avg_price;
DUMP q4;

-- Q5 Top 3 medicines by stock value
o5 = ORDER v BY stock_value DESC;
l5 = LIMIT o5 3;
q5 = FOREACH l5 GENERATE Medicine_Name, stock_value;
DUMP q5;

-- Q6 Total stock quantity and stock value per supplier
g6 = GROUP v BY Supplier_ID;
q6 = FOREACH g6 GENERATE group AS Supplier_ID, SUM(v.Stock_Quantity) AS total_qty,
       SUM(v.stock_value) AS stock_value;
DUMP q6;
