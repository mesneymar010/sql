-- bank_transactions.csv   Run:  pig -x local scripts/pig/bank.pig
raw  = LOAD '/lab/data/bank_transactions.csv' USING PigStorage(',')
       AS (Transaction_ID:chararray, Customer_ID:chararray, Account_Type:chararray,
           Transaction_Type:chararray, Amount:int, Branch:chararray, Transaction_Date:chararray);
bank = FILTER raw BY Transaction_ID != 'Transaction_ID';     -- remove the header line

-- Q1 Total amount per branch
g1 = GROUP bank BY Branch;
q1 = FOREACH g1 GENERATE group AS Branch, SUM(bank.Amount) AS total;
DUMP q1;

-- Q2 Count and total amount per transaction type
g2 = GROUP bank BY Transaction_Type;
q2 = FOREACH g2 GENERATE group AS Transaction_Type, COUNT(bank) AS cnt, SUM(bank.Amount) AS total;
DUMP q2;

-- Q3 Deposits greater than 5000
f3 = FILTER bank BY Transaction_Type == 'Deposit' AND Amount > 5000;
q3 = FOREACH f3 GENERATE Transaction_ID, Customer_ID, Amount, Branch;
DUMP q3;

-- Q4 Net balance per customer (deposits minus withdrawals)
s4 = FOREACH bank GENERATE Customer_ID,
       (Transaction_Type == 'Deposit' ? Amount : -Amount) AS signed_amount;
g4 = GROUP s4 BY Customer_ID;
q4 = FOREACH g4 GENERATE group AS Customer_ID, SUM(s4.signed_amount) AS net;
DUMP q4;

-- Q5 Top 3 branches by total amount
o5 = ORDER q1 BY total DESC;
q5 = LIMIT o5 3;
DUMP q5;

-- Q6 Average amount per account type
g6 = GROUP bank BY Account_Type;
q6 = FOREACH g6 GENERATE group AS Account_Type, ROUND_TO(AVG(bank.Amount), 2) AS avg_amount;
DUMP q6;
