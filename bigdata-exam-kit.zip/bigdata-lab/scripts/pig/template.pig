-- ===========================================================================
-- PIG TEMPLATE: copy this file (e.g. to q1.pig), keep what is needed, delete the rest.
-- Run inside the Pig container:   pig -x local scripts/pig/q1.pig
-- As delivered it runs on data/bank_transactions.csv.
-- ===========================================================================

-- 1. LOAD: file path, separator, and one name:type per column (same order as the file)
--    types: chararray (text), int, long, double
raw  = LOAD '/lab/data/bank_transactions.csv' USING PigStorage(',')
       AS (Transaction_ID:chararray, Customer_ID:chararray, Account_Type:chararray,
           Transaction_Type:chararray, Amount:int, Branch:chararray, Transaction_Date:chararray);

-- 2. Remove the header line (first column is not equal to its own title)
data = FILTER raw BY Transaction_ID != 'Transaction_ID';

-- 3. FILTER: keep rows (==  !=  >  >=  <  <=  AND  OR  NOT,  text: matches 'Dep.*')
dep  = FILTER data BY Transaction_Type == 'Deposit' AND Amount >= 5000;

-- 4. FOREACH ... GENERATE: choose / calculate columns
--    (double) before a division avoids whole-number division: (double) a / b
cols = FOREACH data GENERATE Transaction_ID, Branch, Amount,
         (Transaction_Type == 'Deposit' ? Amount : -Amount) AS signed_amount,
         SUBSTRING(Transaction_Date, 0, 7) AS month;

-- 5. GROUP + aggregate: COUNT, SUM, AVG, MAX, MIN    (group = the grouped value)
grp  = GROUP data BY Branch;
agg  = FOREACH grp GENERATE group AS Branch, COUNT(data) AS cnt, SUM(data.Amount) AS total,
         ROUND_TO(AVG(data.Amount), 2) AS average, MAX(data.Amount) AS highest;

--    group by two columns:
grp2 = GROUP data BY (Branch, Transaction_Type);
agg2 = FOREACH grp2 GENERATE FLATTEN(group) AS (Branch, Transaction_Type), SUM(data.Amount) AS total;

--    whole file (one result row):
all1 = GROUP data ALL;
tot  = FOREACH all1 GENERATE COUNT(data) AS rows, SUM(data.Amount) AS total;

--    count different values (DISTINCT inside FOREACH)
cust = FOREACH grp { c = DISTINCT data.Customer_ID; GENERATE group AS Branch, COUNT(c) AS customers; };

-- 6. Condition on the aggregated value (like SQL HAVING)
big  = FILTER agg BY total > 10000;

-- 7. ORDER + LIMIT (top N)
srt  = ORDER agg BY total DESC;
top3 = LIMIT srt 3;

-- 8. DISTINCT values of a column
br   = FOREACH data GENERATE Branch;
brd  = DISTINCT br;

-- 9. JOIN two relations on a common column
j    = JOIN data BY Branch, agg BY Branch;
jout = FOREACH j GENERATE data::Transaction_ID, data::Branch, data::Amount, agg::total;

-- 10. Show results on screen ...
DUMP top3;
DESCRIBE agg;
-- ... or save them in a folder (comma separated); rmf deletes an old result first
rmf /lab/output/pig_top3
STORE top3 INTO '/lab/output/pig_top3' USING PigStorage(',');
