-- medical_records.csv   Run:  pig -x local scripts/pig/medical.pig
raw = LOAD '/lab/data/medical_records.csv' USING PigStorage(',')
      AS (Patient_ID:chararray, Age:int, Gender:chararray, Diagnosis:chararray,
          Blood_Sugar:int, Blood_Pressure:chararray, Doctor_Specialization:chararray);
med = FILTER raw BY Patient_ID != 'Patient_ID';              -- remove the header line

-- Q1 Number of patients per diagnosis
g1 = GROUP med BY Diagnosis;
q1 = FOREACH g1 GENERATE group AS Diagnosis, COUNT(med) AS patients;
DUMP q1;

-- Q2 Average blood sugar per diagnosis
q2 = FOREACH g1 GENERATE group AS Diagnosis, ROUND_TO(AVG(med.Blood_Sugar), 2) AS avg_sugar;
DUMP q2;

-- Q3 Patients with blood sugar above 140
f3 = FILTER med BY Blood_Sugar > 140;
q3 = FOREACH f3 GENERATE Patient_ID, Age, Blood_Sugar;
DUMP q3;

-- Q4 Average age per gender
g4 = GROUP med BY Gender;
q4 = FOREACH g4 GENERATE group AS Gender, ROUND_TO(AVG(med.Age), 2) AS avg_age;
DUMP q4;

-- Q5 Patients with systolic blood pressure 140 or more ("140/90" split into two numbers)
b5 = FOREACH med GENERATE Patient_ID,
       (int) REGEX_EXTRACT(Blood_Pressure, '(\\d+)/(\\d+)', 1) AS systolic,
       (int) REGEX_EXTRACT(Blood_Pressure, '(\\d+)/(\\d+)', 2) AS diastolic;
q5 = FILTER b5 BY systolic >= 140;
DUMP q5;

-- Q6 Number of patients per age group
a6 = FOREACH med GENERATE
       (CASE WHEN Age < 40 THEN 'Below 40'
             WHEN Age < 60 THEN '40-59'
             ELSE '60 and above' END) AS age_group;
g6 = GROUP a6 BY age_group;
q6 = FOREACH g6 GENERATE group AS age_group, COUNT(a6) AS patients;
DUMP q6;
