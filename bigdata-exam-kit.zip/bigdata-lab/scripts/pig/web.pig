-- web_clicks.csv   Run:  pig -x local scripts/pig/web.pig
raw = LOAD '/lab/data/web_clicks.csv' USING PigStorage(',')
      AS (Click_ID:chararray, User_ID:chararray, Country:chararray, Device_Type:chararray,
          Page_Category:chararray, Click_Time:chararray, Session_ID:chararray, Duration_Seconds:int);
clicks = FILTER raw BY Click_ID != 'Click_ID';               -- remove the header line

-- Q1 Number of clicks per country
g1 = GROUP clicks BY Country;
q1 = FOREACH g1 GENERATE group AS Country, COUNT(clicks) AS num_clicks;
DUMP q1;

-- Q2 Average duration (seconds) per device type
g2 = GROUP clicks BY Device_Type;
q2 = FOREACH g2 GENERATE group AS Device_Type, ROUND_TO(AVG(clicks.Duration_Seconds), 2) AS avg_duration;
DUMP q2;

-- Q3 Total duration per page category (highest first)
g3 = GROUP clicks BY Page_Category;
s3 = FOREACH g3 GENERATE group AS Page_Category, SUM(clicks.Duration_Seconds) AS total_duration;
q3 = ORDER s3 BY total_duration DESC;
DUMP q3;

-- Q4 Clicks on the Checkout page
f4 = FILTER clicks BY Page_Category == 'Checkout';
q4 = FOREACH f4 GENERATE Click_ID, User_ID, Country;
DUMP q4;

-- Q5 Number of clicks per day (first 10 characters of Click_Time = the date)
d5 = FOREACH clicks GENERATE SUBSTRING(Click_Time, 0, 10) AS click_day;
g5 = GROUP d5 BY click_day;
q5 = FOREACH g5 GENERATE group AS click_day, COUNT(d5) AS num_clicks;
DUMP q5;

-- Q6 Number of different users per country
q6 = FOREACH g1 {
       u = DISTINCT clicks.User_ID;
       GENERATE group AS Country, COUNT(u) AS users;
     };
DUMP q6;
