// CsvQuery: one generic Hadoop MapReduce program for CSV files that have a header row.
// It answers "group by / count / sum / average / max / min / filter" questions
// without changing any code. Columns are given by NAME (as in the header line).
//
// Usage (inside the Hadoop container, from /lab):
//   bash scripts/hadoop/run.sh CsvQuery <input.csv> <output-folder> <group-by> <operation> [value] [filter ...]
//
//   group-by   : a column name, several names joined with "," (e.g. Branch,Account_Type), or ALL
//   operation  : count | sum | avg | max | min | stats | list | distinct | countdistinct
//   value      : a column name, or a calculation done left to right with + - * /
//                e.g. Amount   Quantity*Unit_Price   Attended_Classes*100/Total_Classes
//                (not needed for count)
//   filter     : Column=Value  Column!=Value  Column>Value  Column>=Value  Column<Value
//                Column<=Value  Column~Text (contains). The right side may also be another
//                column, e.g. Stock_Quantity<Reorder_Level. Several filters = all must hold.
//
// Examples:
//   ... CsvQuery data/bank_transactions.csv output/q1 Branch sum Amount
//   ... CsvQuery data/bank_transactions.csv output/q2 Customer_ID sum Amount Transaction_Type=Deposit
//   ... CsvQuery data/retail_sales.csv output/q3 Category sum Quantity*Unit_Price
//   ... CsvQuery data/pharmacy_inventory.csv output/q4 ALL list Medicine_Name Stock_Quantity<Reorder_Level

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class CsvQuery {

    static final String SEP = "\u0001";   // separates parts inside one setting
    static final String LIST = "\u0002";  // separates list items inside one setting

    // ---------------------------------------------------------------- Mapper
    // Reads one line, skips the header, applies the filters,
    // and emits (group-by value, value to aggregate).
    public static class QueryMapper extends Mapper<Object, Text, Text, Text> {
        private String header;
        private int[] keyCols;          // empty = ALL
        private String[] valueTokens;   // e.g. ["#4", "*", "#5"]; "#n" = column n
        private List<String[]> filters = new ArrayList<String[]>();  // {col, op, rhs}

        @Override
        protected void setup(Context context) {
            Configuration conf = context.getConfiguration();
            header = conf.get("csvquery.header", "");
            String k = conf.get("csvquery.keys", "");
            if (k.isEmpty()) {
                keyCols = new int[0];
            } else {
                String[] p = k.split(SEP);
                keyCols = new int[p.length];
                for (int i = 0; i < p.length; i++) keyCols[i] = Integer.parseInt(p[i]);
            }
            String v = conf.get("csvquery.value", "");
            valueTokens = v.isEmpty() ? new String[0] : v.split(SEP);
            String f = conf.get("csvquery.filters", "");
            if (!f.isEmpty()) {
                for (String one : f.split(LIST)) filters.add(one.split(SEP, -1));
            }
        }

        @Override
        public void map(Object offset, Text value, Context context)
                throws IOException, InterruptedException {
            String line = value.toString().replace("\r", "");
            if (line.trim().isEmpty() || line.trim().equals(header)) return;   // skip header / blank lines
            String[] f = line.split(",", -1);
            for (String[] flt : filters) {
                if (!passes(f, flt)) return;
            }
            String key;
            if (keyCols.length == 0) {
                key = "ALL";
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < keyCols.length; i++) {
                    if (i > 0) sb.append(',');
                    sb.append(field(f, keyCols[i]));
                }
                key = sb.toString();
            }
            String out;
            if (valueTokens.length == 0) {
                out = "1";
            } else if (valueTokens.length == 1) {
                out = token(f, valueTokens[0]);                 // a single column: keep as written
            } else {
                Double r = calculate(f);
                if (r == null) return;                          // not a number in this row
                out = String.valueOf(r);
            }
            context.write(new Text(key), new Text(out));
        }

        private static String field(String[] f, int i) {
            return i < f.length ? f[i].trim() : "";
        }

        private static String token(String[] f, String t) {
            return t.startsWith("#") ? field(f, Integer.parseInt(t.substring(1))) : t;
        }

        private Double calculate(String[] f) {             // left to right: a op b op c ...
            Double acc = number(token(f, valueTokens[0]));
            for (int i = 1; i + 1 < valueTokens.length && acc != null; i += 2) {
                Double b = number(token(f, valueTokens[i + 1]));
                if (b == null) return null;
                switch (valueTokens[i]) {
                    case "+": acc = acc + b; break;
                    case "-": acc = acc - b; break;
                    case "*": acc = acc * b; break;
                    default:  if (b == 0) return null; acc = acc / b;
                }
            }
            return acc;
        }

        private static boolean passes(String[] f, String[] flt) {
            String left = field(f, Integer.parseInt(flt[0]));
            String op = flt[1];
            String right = flt[2].startsWith("#") ? token(f, flt[2]) : flt[2].substring(1);
            if (op.equals("~")) return left.contains(right);
            Double a = number(left), b = number(right);
            int cmp = (a != null && b != null) ? Double.compare(a, b) : left.compareTo(right);
            switch (op) {
                case "=":  return cmp == 0;
                case "!=": return cmp != 0;
                case ">":  return cmp > 0;
                case ">=": return cmp >= 0;
                case "<":  return cmp < 0;
                default:   return cmp <= 0;   // "<="
            }
        }
    }

    // --------------------------------------------------------------- Reducer
    // Receives all values of one group and calculates the requested result.
    public static class QueryReducer extends Reducer<Text, Text, Text, Text> {
        private String op;

        @Override
        protected void setup(Context context) {
            op = context.getConfiguration().get("csvquery.op", "count");
        }

        @Override
        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            long count = 0, numbers = 0;
            double sum = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            List<String> all = new ArrayList<String>();
            for (Text t : values) {
                String s = t.toString();
                count++;
                all.add(s);
                Double d = number(s);
                if (d != null) {
                    numbers++;
                    sum += d;
                    max = Math.max(max, d);
                    min = Math.min(min, d);
                }
            }
            String result;
            switch (op) {
                case "count":         result = String.valueOf(count); break;
                case "sum":           result = show(sum); break;
                case "avg":           result = numbers == 0 ? "" : show(sum / numbers); break;
                case "max":           result = numbers == 0 ? "" : show(max); break;
                case "min":           result = numbers == 0 ? "" : show(min); break;
                case "stats":         result = numbers == 0 ? "" : "count=" + count + " sum=" + show(sum)
                                               + " avg=" + show(sum / numbers) + " min=" + show(min) + " max=" + show(max);
                                      break;
                case "list":          Collections.sort(all); result = String.join(" | ", all); break;
                case "distinct":      result = String.join(" | ", new TreeSet<String>(all)); break;
                default:              result = String.valueOf(new TreeSet<String>(all).size());   // countdistinct
            }
            context.write(key, new Text(result));
        }
    }

    // ---------------------------------------------------------------- helpers
    static Double number(String s) {
        try {
            return Double.valueOf(s.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static String show(double d) {               // 12150.0 -> 12150 ; 4641.666... stays exact
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    static int column(List<String> names, String name) {
        for (int i = 0; i < names.size(); i++) {
            if (names.get(i).equalsIgnoreCase(name.trim())) return i;
        }
        throw new IllegalArgumentException("Unknown column \"" + name + "\". Columns are: " + names);
    }

    static String firstLine(Configuration conf, Path in) throws IOException {
        FileSystem fs = in.getFileSystem(conf);
        Path file = in;
        if (fs.getFileStatus(in).isDirectory()) {
            file = null;
            for (FileStatus st : fs.listStatus(in)) {
                String n = st.getPath().getName();
                if (!st.isDirectory() && !n.startsWith("_") && !n.startsWith(".")) { file = st.getPath(); break; }
            }
            if (file == null) throw new IOException("No input file in " + in);
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(fs.open(file), "UTF-8"));
        try {
            String h = r.readLine();
            return h == null ? "" : h.replace("\r", "").replace("﻿", "").trim();
        } finally {
            r.close();
        }
    }

    // ------------------------------------------------------------------ main
    public static void main(String[] args) throws Exception {
        try {
            System.exit(run(args));
        } catch (IllegalArgumentException e) {
            System.err.println("ERROR: " + e.getMessage());
            System.exit(2);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length < 4) {
            System.err.println("Usage: CsvQuery <input> <output> <group-by|ALL> "
                    + "<count|sum|avg|max|min|stats|list|distinct|countdistinct> [value] [filter ...]");
            return 2;
        }
        Configuration conf = new Configuration();
        String header = firstLine(conf, new Path(args[0]));
        List<String> names = new ArrayList<String>();
        for (String h : header.split(",", -1)) names.add(h.trim());

        String op = args[3].toLowerCase(Locale.ROOT);
        List<String> ops = java.util.Arrays.asList("count", "sum", "avg", "max", "min", "stats", "list", "distinct", "countdistinct");
        if (!ops.contains(op)) throw new IllegalArgumentException("Unknown operation \"" + args[3] + "\". Use one of " + ops);

        // group-by columns
        StringBuilder keys = new StringBuilder();
        if (!args[2].equalsIgnoreCase("ALL")) {
            for (String k : args[2].split(",")) {
                if (keys.length() > 0) keys.append(SEP);
                keys.append(column(names, k));
            }
        }

        // value (column or calculation) and filters
        Pattern filterPattern = Pattern.compile("^(.+?)(>=|<=|!=|=|>|<|~)(.*)$");
        int next = 4;
        StringBuilder value = new StringBuilder();
        if (args.length > 4 && !filterPattern.matcher(args[4]).matches()) {
            for (String t : args[4].split("(?=[-+*/])|(?<=[-+*/])")) {
                t = t.trim();
                if (t.isEmpty()) continue;
                if (value.length() > 0) value.append(SEP);
                if ("+-*/".contains(t)) value.append(t);
                else if (number(t) != null) value.append(t);
                else value.append('#').append(column(names, t));
            }
            next = 5;
        }
        if (!op.equals("count") && value.length() == 0) {
            throw new IllegalArgumentException("Operation \"" + op + "\" needs a value column, e.g. Amount");
        }
        StringBuilder filters = new StringBuilder();
        for (int i = next; i < args.length; i++) {
            Matcher m = filterPattern.matcher(args[i]);
            if (!m.matches()) throw new IllegalArgumentException("Not a filter: \"" + args[i] + "\" (example: Amount>5000)");
            String rhs = m.group(3).trim();
            boolean isColumn = false;
            for (String n : names) if (n.equalsIgnoreCase(rhs)) isColumn = true;
            if (filters.length() > 0) filters.append(LIST);
            filters.append(column(names, m.group(1))).append(SEP).append(m.group(2)).append(SEP)
                   .append(isColumn ? "#" + column(names, rhs) : "=" + rhs);
        }

        conf.set("csvquery.header", header);
        conf.set("csvquery.keys", keys.toString());
        conf.set("csvquery.value", value.toString());
        conf.set("csvquery.filters", filters.toString());
        conf.set("csvquery.op", op);

        Job job = Job.getInstance(conf, "CsvQuery " + args[2] + " " + op);
        job.setJarByClass(CsvQuery.class);
        job.setMapperClass(QueryMapper.class);
        job.setReducerClass(QueryReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        return job.waitForCompletion(true) ? 0 : 1;
    }
}
