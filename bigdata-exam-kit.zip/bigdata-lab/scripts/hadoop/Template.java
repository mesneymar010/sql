// Template: a short, standard MapReduce program for one CSV question.
// As delivered it answers: "total Amount per Branch" in data/bank_transactions.csv.
//
// To answer another question, copy this file, e.g. to BranchTotal.java, then:
//   1. change the class name "Template" (3 places) to the new file name (BranchTotal)
//   2. change KEY_COL, VALUE_COL and OPERATION below
//   3. optionally add a filter in map() (see the example comment)
// Columns are counted from 0:  Transaction_ID=0, Customer_ID=1, ..., Amount=4, Branch=5
//
// Run (inside the Hadoop container, from /lab):
//   bash scripts/hadoop/run.sh Template data/bank_transactions.csv output/template

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Template {

    static final int KEY_COL = 5;            // group by this column   (5 = Branch)
    static final int VALUE_COL = 4;          // numbers from this column (4 = Amount)
    static final String OPERATION = "sum";   // sum | count | avg | max | min

    // Mapper: one line in -> (key, number) out
    public static class MyMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
        @Override
        public void map(LongWritable offset, Text line, Context context)
                throws IOException, InterruptedException {
            if (offset.get() == 0) return;                       // skip the header line
            String[] f = line.toString().trim().split(",");
            if (f.length <= Math.max(KEY_COL, VALUE_COL)) return; // skip empty/short lines

            // Example filter (remove the // to use it): only deposits
            // if (!f[3].equals("Deposit")) return;

            String key = f[KEY_COL];
            double number = (OPERATION.equals("count")) ? 1 : Double.parseDouble(f[VALUE_COL]);
            context.write(new Text(key), new DoubleWritable(number));
        }
    }

    // Reducer: all numbers of one key in -> one result out
    public static class MyReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
        @Override
        public void reduce(Text key, Iterable<DoubleWritable> values, Context context)
                throws IOException, InterruptedException {
            double sum = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            long count = 0;
            for (DoubleWritable v : values) {
                double x = v.get();
                sum += x;
                count++;
                max = Math.max(max, x);
                min = Math.min(min, x);
            }
            double result;
            if (OPERATION.equals("count"))     result = count;
            else if (OPERATION.equals("avg"))  result = sum / count;
            else if (OPERATION.equals("max"))  result = max;
            else if (OPERATION.equals("min"))  result = min;
            else                               result = sum;
            context.write(key, new DoubleWritable(result));
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Template");
        job.setJarByClass(Template.class);
        job.setMapperClass(MyMapper.class);
        job.setReducerClass(MyReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
