#!/usr/bin/env bash
# Compiles and runs one MapReduce program from scripts/hadoop, then shows the result.
# Use INSIDE the Hadoop container (start-hadoop), from /lab:
#   bash scripts/hadoop/run.sh <ClassName> <input> <output-folder> [more arguments]
# Examples:
#   bash scripts/hadoop/run.sh Template data/bank_transactions.csv output/template
#   bash scripts/hadoop/run.sh CsvQuery data/bank_transactions.csv output/q1 Branch sum Amount
# An existing output folder inside output/ is deleted first, so a program can be re-run.

CLASS="$1"; IN="$2"; OUT="$3"
if [ -z "$CLASS" ] || [ -z "$IN" ] || [ -z "$OUT" ]; then
    echo "Usage: bash scripts/hadoop/run.sh <ClassName> <input> <output-folder> [more arguments]"
    exit 2
fi
shift 3
cd /lab || exit 1
SRC="scripts/hadoop/$CLASS.java"
[ -f "$SRC" ] || { echo "ERROR: $SRC not found (the file name must equal the class name)"; exit 1; }
[ -e "$IN" ]  || { echo "ERROR: input $IN not found"; exit 1; }

echo ">> compiling $SRC"
rm -rf "build/$CLASS"; mkdir -p "build/$CLASS"
javac -cp "$(hadoop classpath)" -d "build/$CLASS" "$SRC" || { echo "ERROR: compilation failed (see the messages above)"; exit 1; }
jar cf "build/$CLASS.jar" -C "build/$CLASS" . || exit 1

case "$OUT" in
    output/?*|/lab/output/?*) rm -rf "$OUT" ;;
    *) [ -e "$OUT" ] && { echo "ERROR: $OUT already exists (use a folder inside output/)"; exit 1; } ;;
esac

echo ">> running $CLASS"
export HADOOP_ROOT_LOGGER="${HADOOP_ROOT_LOGGER:-WARN,console}"
hadoop jar "build/$CLASS.jar" "$CLASS" "$IN" "$OUT" "$@" || { echo "ERROR: the job failed (see the messages above)"; exit 1; }

echo ">> result ($OUT):"
cat "$OUT"/part-*
